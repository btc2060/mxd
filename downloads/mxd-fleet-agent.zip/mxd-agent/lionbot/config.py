from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Floor:
    y: float
    left: float | None
    right: float | None

    @property
    def configured(self) -> bool:
        return self.left is not None and self.right is not None


@dataclass(frozen=True)
class Config:
    behavior: str = "patrol"
    monster_name: str = "蓝独角狮"
    station: tuple[float, float] | None = None
    station_tolerance: float = 0.008
    # 定点回位连续多久未向目标取得进展才暂停，不是整个回位过程的总时限。
    station_recover_timeout: float = 6.0
    station_step_recovery: bool = True
    station_step_max_attempts: int = 3
    station_step_timeout: float = 15.0
    stationary_fps: float = 10.0
    plant_color_fallback: bool = True
    plant_color_frames: int = 3
    window_title: str = "冒险岛怀旧服"
    # 以下 ROI 均为游戏客户区像素坐标 [x, y, width, height]。
    minimap_roi: tuple[int, int, int, int] | None = None
    combat_roi: tuple[int, int, int, int] | None = None
    frame_size: tuple[int, int] | None = None
    player_template: str = "calibration/player.png"
    player_feet_offset: tuple[float, float] | None = None
    screen_anchor: str = "calibration/screen-anchor.json"
    template_manifest: str = "calibration/monsters.json"
    world_pixels_per_x: float | None = None
    bottom: Floor = Floor(0.759, 0.029, 0.659)
    top: Floor = Floor(0.130, 0.045, 0.212)
    floor_tolerance: float = 0.035
    # 只向内缩 0.055，仍可覆盖距边缘 0.086 内的怪物。
    turn_inset: float = 0.055
    attack_range: float = 0.086
    attack_range_px: float | None = None
    attack_interval: float = 0.9
    attack_hold: float = 0.08
    face_hold: float = 0.08
    alt_interval: float = 190.0
    teleport_max_dx: float | None = None
    teleport_cooldown: float = 12.0
    teleport_settle: float = 0.35
    boundary_margin: float = 0.012
    scan_step: float = 0.05
    scan_seconds: float = 0.22
    empty_seconds: float = 3.0
    empty_sweeps: int = 2
    # 旧脚底容差保留用于读取旧配置；攻击带现在使用角色实际身高。
    feet_tolerance_px: float = 22.0
    player_height_px: float = 64.0
    confirmation_frames: int = 2
    confirmation_gap: float = 0.35
    hurt_recovery_seconds: float = 1.2
    hurt_threshold: float = 0.72
    target_memory_seconds: float = 1.45
    target_reacquire_seconds: float = 0.4
    attack_burst_shots: int = 3
    patrol_policy_version: int = 2
    patrol_round_trips: int = 3
    random_attack_min_seconds: float = 6.0
    random_attack_max_seconds: float = 12.0
    random_attack_max_shots: int = 2
    clear_seconds: float = 0.8
    clear_frames: int = 3
    combat_localization_grace: float = 1.2
    player_partial_seconds: float = 0.35
    player_threshold: float = 0.82
    monster_threshold: float = 0.82
    edge_threshold: float = 0.40
    # 用户已确认 X=.212 直通顶层，顶层 X=.045 可向左走落。
    auto_route: bool = True
    ladder_x: float = 0.212
    ladder_tolerance: float = 0.008
    ladder_align_frames: int = 3
    ladder_nudge_seconds: float = 0.02
    ladder_align_timeout: float = 5.0
    ladder_max_attempts: int = 3
    grab_confirm_seconds: float = 0.8
    grab_timeout: float = 2.2
    grab_min_rise: float = 0.02
    climb_timeout: float = 18.0
    climb_stuck_seconds: float = 1.5
    top_drop_x: float | None = 0.045
    drop_direction: str = "left"

    @property
    def attack_reach_px(self) -> float | None:
        if self.attack_range_px is not None:
            return self.attack_range_px
        return self.attack_range * self.world_pixels_per_x if self.world_pixels_per_x is not None else None

    def validate(self) -> None:
        if self.behavior not in ("patrol", "stationary"):
            raise ValueError("behavior 只能是 patrol 或 stationary")
        if (not 5 <= self.stationary_fps <= 20 or type(self.plant_color_fallback) is not bool
                or type(self.plant_color_frames) is not int or not 2 <= self.plant_color_frames <= 10):
            raise ValueError("定点帧率为 5～20，颜色补识别开关为布尔值，确认帧数为 2～10")
        if self.station is not None and (len(self.station) != 2 or not all(0 <= v <= 1 for v in self.station)):
            raise ValueError("定点 station 必须为小地图归一化坐标 [X, Y]")
        if not 0 < self.station_tolerance <= .05 or self.station_recover_timeout <= 0:
            raise ValueError("定点 X 容差必须为 (0, 0.05]，回位超时必须为正数")
        if (type(self.station_step_recovery) is not bool or type(self.station_step_max_attempts) is not int
                or not 1 <= self.station_step_max_attempts <= 5 or self.station_step_timeout <= 0):
            raise ValueError("台阶返回开关必须为布尔值，尝试次数为 1～5，超时必须为正数")
        if self.behavior == "stationary" and self.auto_route:
            raise ValueError("定点模式需要 auto_route=false，使用独立地图配置")
        if self.attack_range_px is not None and not 0 < self.attack_range_px <= 4096:
            raise ValueError("攻击像素射程 attack_range_px 必须为 (0, 4096]")
        for floor in (self.bottom, self.top):
            if not 0 <= floor.y <= 1:
                raise ValueError("楼层 Y 必须是小地图归一化坐标")
            if (floor.left is None) != (floor.right is None):
                raise ValueError("楼层左右端必须一起设置")
            if floor.configured and not 0 <= floor.left < floor.right <= 1:
                raise ValueError("楼层左右端必须满足 0 <= left < right <= 1")
            if floor.configured and 2 * self.turn_inset >= floor.right - floor.left:
                raise ValueError("掉头内缩量超过平台宽度")
        for roi in (self.minimap_roi, self.combat_roi):
            if roi is not None and (len(roi) != 4 or min(roi[:2]) < 0 or min(roi[2:]) <= 0):
                raise ValueError("ROI 必须为 [x, y, width, height]")
        if not 0 < self.attack_hold < self.attack_interval or self.attack_interval < 0.9:
            raise ValueError("攻击间隔至少 0.9 秒，按住时间必须小于间隔")
        if not .03 <= self.face_hold <= .2:
            raise ValueError("转身按键 face_hold 必须为 0.03～0.2 秒")
        if self.alt_interval <= 0 or not 0 < self.attack_range <= 1:
            raise ValueError("Alt 周期和攻击距离必须为正数")
        if self.world_pixels_per_x is not None and self.world_pixels_per_x <= 0:
            raise ValueError("主画面/小地图比例必须为正数")
        if self.teleport_max_dx is not None and not 0 < self.teleport_max_dx < 1:
            raise ValueError("瞬移最大位移必须在 (0, 1) 内")
        if self.confirmation_frames < 2 or self.empty_sweeps < 1:
            raise ValueError("至少连续两帧确认怪物，至少巡视一个往返")
        if not 12 <= self.player_height_px <= 512:
            raise ValueError("角色身高 player_height_px 必须为 12～512 主画面像素")
        if not 0 < self.hurt_threshold <= self.monster_threshold <= 1:
            raise ValueError("受击追踪阈值必须不高于正常识别阈值，且位于 (0, 1]")
        if not 0 < self.confirmation_gap <= self.hurt_recovery_seconds <= 2:
            raise ValueError("识别间断和受击追踪时间必须满足 0 < gap <= recovery <= 2 秒")
        if type(self.attack_burst_shots) is not int or self.attack_burst_shots < 1:
            raise ValueError("attack_burst_shots 必须为正整数，例如 3 或 6")
        if self.patrol_round_trips < 1:
            raise ValueError("底层巡逻往返次数至少为 1")
        if not 0 < self.random_attack_min_seconds <= self.random_attack_max_seconds:
            raise ValueError("随机攻击时间范围必须为正数且按先小后大设置")
        if not 1 <= self.random_attack_max_shots <= 3:
            raise ValueError("一组随机攻击必须为 1～3 次")
        if not 0 < self.clear_seconds <= 5 or self.clear_frames < 2:
            raise ValueError("清怪确认必须至少两帧，持续时间在 (0, 5] 秒内")
        if not 0 < self.combat_localization_grace <= 3:
            raise ValueError("战斗定位丢失的等待时间必须在 (0, 3] 秒内")
        if self.ladder_align_frames < 2 or not .005 <= self.ladder_nudge_seconds <= .05:
            raise ValueError("爬绳对齐至少确认两帧，微调按键为 0.005～0.05 秒")
        if not 1 <= self.ladder_max_attempts <= 5 or self.ladder_align_timeout <= 0:
            raise ValueError("抓绳尝试次数必须为 1～5，对齐超时必须为正数")
        if not 0 < self.grab_confirm_seconds < self.grab_timeout or not 0 < self.grab_min_rise < 1:
            raise ValueError("抓绳确认时间必须小于超时，确认上升量必须在 (0, 1) 内")
        if not 0 < self.target_reacquire_seconds < self.target_memory_seconds <= 2:
            raise ValueError("目标重查时间必须小于记忆时间，记忆最长 2 秒")
        if not 0 < self.player_partial_seconds <= 0.5:
            raise ValueError("局部名牌识别最长 0.5 秒")
        if not 0 <= self.turn_inset <= self.attack_range - self.boundary_margin:
            raise ValueError("掉头点必须在边缘攻击范围内，并留出余量")
        if self.auto_route:
            if not self.top.configured or self.top_drop_x is None:
                raise ValueError("自动换层需要顶层左右端和 top_drop_x")
            if not self.top.left <= self.top_drop_x <= self.top.right:
                raise ValueError("top_drop_x 必须位于顶层范围内")
            if not self.bottom.left <= self.ladder_x <= self.bottom.right:
                raise ValueError("梯子不在底层范围内")
            if self.drop_direction not in ("left", "right"):
                raise ValueError("drop_direction 只能是 left 或 right")

    def require_calibration(self) -> None:
        self.validate()
        if self.behavior == "stationary" and (self.station is None or self.attack_range_px is None):
            raise ValueError("尚未采集定点坐标或像素射程；请运行 python -m lionbot --config <配置路径> --calibrate-stationary")
        required = {"小地图范围": self.minimap_roi, "主画面范围": self.combat_roi,
                    "窗口尺寸": self.frame_size}
        missing = [name for name, value in required.items() if value is None]
        if missing:
            raise ValueError("尚缺少" + "、".join(missing)
                             + "；请运行 python -m lionbot --calibrate，已保存的步骤会自动续做")
        if self.world_pixels_per_x is None:
            if self.behavior == "stationary":
                raise ValueError("黄点与主画面的比例尚未完成，请在此配置下重新运行 --calibrate-stationary 续做；无需测量 F")
            raise ValueError("截图区域和角色位置已保存，但射程比例尚未完成；请先运行 "
                             "python -m lionbot --measure-scale，再运行 --measure-teleport")


def load_config(path: str | Path) -> Config:
    source = Path(path)
    raw = json.loads(source.read_text(encoding="utf-8")) if source.exists() else {}
    if raw.get("patrol_policy_version", 1) < 2:
        # 仅升级旧版默认的两次攻击，保留用户自定义次数（例如六次）。
        raw["patrol_policy_version"] = 2
        if type(raw.get("attack_burst_shots")) is int and raw["attack_burst_shots"] == 2:
            raw["attack_burst_shots"] = 3
    for name in ("bottom", "top"):
        if name in raw:
            raw[name] = Floor(**raw[name])
    for name in ("minimap_roi", "combat_roi", "frame_size", "player_feet_offset", "station"):
        if raw.get(name) is not None:
            raw[name] = tuple(raw[name])
    config = Config(**raw)
    config.validate()
    return config
